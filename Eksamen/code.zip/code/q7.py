import numpy as np
import statistics
from matplotlib.colors import ListedColormap
import matplotlib.pyplot as plt
import sys

def loaddata(filename):
    """Load the balloon data set from filename and return t, X
        t - N-dim. vector of target (temperature) values
        X - N-dim. vector containing the inputs (lift) x for each data point
    """
    # Load data set from CSV file
    Xt = np.loadtxt(filename, delimiter=',')

    # Split into data matrix and target vector
    X = Xt[:,:-1]
    t = Xt[:,-1]
    
    return t, X

# Load data
t, X = loaddata('../data/seedsDataset.txt')

class KMean():
    def __init__(self, sample, nClusters = 5, nIterations = 5):
        self.samples = sample
        self.nClusters = nClusters
        self.nIterations = nIterations
    
    def normalize(self):
        means = self.samples.mean(axis = 0)
        deviations = []
        norm = np.zeros(self.samples.shape)

        for c in self.samples.T:
            sampleStandardDeviation = statistics.stdev(c)
            deviations.append(sampleStandardDeviation)

        for i in range(self.samples.shape[0]):
            for j in range(self.samples.shape[1]):
                norm[i, j] = (self.samples[i, j] - means[j]) / deviations[j]
        self.normalizedData = norm

    def calculateMean(self, centroid, assignedTo):
        temp = []
        for j in range(self.normalizedData.shape[0]):
            if assignedTo[j] == centroid:
                temp.append(self.normalizedData[j])
        return sum(temp) / len(temp)

    def kMeans(self):
        centroids = np.zeros((self.nClusters, self.normalizedData.shape[1]))
        for i in range(self.nClusters):
            randomRow = np.random.randint(self.normalizedData.shape[0] - 1)
            centroids[i] = self.normalizedData[randomRow]
        assigntedToComp = np.zeros(self.normalizedData.shape[0])
        assigntedTo = []
        while(1):
            for i in range(self.normalizedData.shape[0]):
                distances = np.zeros(self.nClusters)
                for j in range(self.nClusters):
                    distances[j] = (np.linalg.norm(self.normalizedData[i]-centroids[j]))
                closest = np.argmin(distances)
                assigntedTo.append(closest)
            if np.array_equal(assigntedToComp, assigntedTo):
                samplesInClusters = []
                for i in range(self.nClusters):
                    samplesInClusters.append(assigntedTo.count(i))
                return centroids, np.array(assigntedTo), np.array(samplesInClusters)
            for centroid in range(self.nClusters):
                centroids[centroid] = self.calculateMean(centroid, assigntedTo)
            assigntedToComp = assigntedTo
            assigntedTo = []

    def KMeansIntra(self):
        optimalDist = sys.maxsize
        optimalClusters = np.zeros((self.nClusters, self.normalizedData.shape[1]))
        optimalAssignedTo = []
        for i in range(self.nIterations):
            centroids, assignedTo, samplesInClusters = self.kMeans()
            clusterDist = 0
            for i in range(1):
                for j in range(self.normalizedData.shape[0]):
                    if assignedTo[i] == assignedTo[j]:
                        clusterDist = clusterDist + np.linalg.norm(self.normalizedData[i]-self.normalizedData[j])
            avgIntraClusterDist = clusterDist / (self.normalizedData.shape[0])
            if avgIntraClusterDist < optimalDist:
                optimalDist = avgIntraClusterDist
                optimalClusters[:] = centroids
                optimalAssignedTo = assignedTo
        self.optimalClusters = optimalClusters
        self.optimalAssignedTo = optimalAssignedTo
        self.optimalDistance = optimalDist
        self.samplesInClusters = samplesInClusters

Kmeans = KMean(sample = X, nClusters = 3)
Kmeans.normalize()
Kmeans.KMeansIntra()

print("Samples in each cluster: ", Kmeans.samplesInClusters)

# from my assignement 5
def PCA(data):
    meanTrainingFeatures = np.mean(data.T, axis = 1)

    dataCent = data.T - meanTrainingFeatures.reshape((-1, 1))
    dataCent = np.cov(dataCent)
    PCevals, PCevecs = np.linalg.eigh(dataCent)
    PCevals = np.flip(PCevals, 0)
    PCevecs = np.flip(PCevecs, 1)
    return PCevals, PCevecs

normEvals, normEvecs = PCA(Kmeans.normalizedData)
optEvals, optEvecs = PCA(Kmeans.optimalClusters)

def transformData(features, PCevecs):
    return np.dot(features,  PCevecs[:, 0:2])

normTransformed = transformData(Kmeans.normalizedData, normEvecs)
optTransformed = transformData(Kmeans.optimalClusters, optEvecs)

# added scatter for centroids.
def visualizeLabels(features, referenceLabels, centroids):
    plt.figure()
    cmapBold  = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])
    y = referenceLabels

    plt.scatter(features[:, 0], features[:, 1], c = y, cmap = cmapBold, s = 10)
    plt.scatter(centroids[:, 0], centroids[:, 1], color="black", s = 100)
    plt.show()

visualizeLabels(normTransformed, t, optTransformed)